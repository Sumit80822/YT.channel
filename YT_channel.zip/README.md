
# YT Channel — GodMode Studio (Demo)

This repository is a deployable starter kit for the **YT GodMode Studio** — a web-based video editor + TTS + compose tool.

## What it includes (demo)
- Simple Express server (placeholders for TTS, compose, upload endpoints)
- Public demo editor (public/editor.html) — create slides, preview, export webm
- README with instructions to deploy on Vercel

## Quick deploy to Vercel
1. Push this repo to GitHub.
2. Create a Vercel account and import this GitHub repo.
3. Set environment variables in Vercel (Project Settings -> Environment Variables):
   - `GOOGLE_CLIENT_ID`
   - `GOOGLE_CLIENT_SECRET`
   - `GOOGLE_REDIRECT` (e.g. https://your-vercel-domain.vercel.app/auth/google/callback)
   - `ELEVEN_API_KEY` (optional)
   - `PEXELS_API_KEY` (optional)
4. Deploy. Visit `https://your-vercel-domain.vercel.app/public/editor.html` to use the editor.

## Notes
- This is a demo starter repo. Full production features (ElevenLabs TTS, FFmpeg compose, YouTube resumable upload) require implementing server endpoints and possibly a render server with FFmpeg.
- For full 4K MP4 rendering, consider using Render.com or a small VPS with FFmpeg installed.

